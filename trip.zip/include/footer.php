<div class="row">
<div class="col-sm-12 text-center">
	<p class="back-link">Copyright 2017 By <a href="http://www.findcode.co.id">FindCode</a></p>
</div>
</div>