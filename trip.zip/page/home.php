<div class="panel panel-default">
    <div class="panel-heading">Selamat Datang <?php echo ucfirst($_SESSION['nama']);?></div>
    <div class="panel-body">
    </div>
</div>